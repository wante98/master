<template>
  <div class="about">
    <h1>This is an about page iview Test OK!!</h1>
    <Slider v-model="value" range />
  </div>
</template>
<script>
    export default {
        data () {
            return {
                value: [20, 50]
            }
        }
    }
</script>